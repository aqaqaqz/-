1. Enter the number of the manga you want in info.txt.
ex) https://xn--9w3b15m8vo.asia/reader/1471310#1-    ->  1471310

2. There is only one number per line.
ex) 
12345
54321

3. Run hiyobi.exe.