package util.utils;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import model.Const;
import model.Msg;
import util.Util;
import util.utils.def.DefaultFileUtil;
import exception.FileException;


public class FileUtil extends DefaultFileUtil {

    /**
     * 애니메이션 분기별로 자동 분류
     */
    public void devideAnimation(String path) {
        File f = Util.file.getFileInfo(path);
        devideAnimation(f);
    }


    public void devideAnimation(File f) {
        try {
            checkValidation(f);

            String title = Util.string.getAnimationTitle(f.getName());
            String movePath = getQuarterAndTitleFolder(title)+"\\"+title+"\\"+f.getName();
            System.out.println(movePath);
            Util.file.moveDirectory(f.getPath(), movePath);
        } catch (FileException e) {
            System.out.println(e.getMessage());
            return;
        }
    }


    /**
     * 로컬에 해당 파일에 부합하는 타이틀이 있는지 확인하고 없는경우 폴더생성
     */
    private String getQuarterAndTitleFolder(String title) {
        // 로컬에 해당 타이틀이 있는지 확인
        String quarter = Util.search.getQuarter(title);

        // 로컬에 없는 경우
        if (Util.string.isEmpty(quarter)) {
            quarter = Util.date.getNowYearAndQuarter();

            // quarter 폴더도 없는 경우
            if (!Util.file.isExist(Const.DEFAULT_PATH + quarter)) {
                Util.file.makeDirectory(Const.DEFAULT_PATH, quarter);
            }

            Util.file.makeDirectory(Const.DEFAULT_PATH + quarter, title);
        }

        return Const.DEFAULT_PATH + quarter;
    }


    /**
     * 분류 대상인지 체크(동영상과 확장자면 분류)
     */
    private void checkValidation(File f) throws FileException {
        if (f.isDirectory()) 
        	throw new FileException(Msg.FILEUTIL_ERROR_DIRECOTRY_NOT_MOVE);

        String extension = getExtension(f.getName());

        if (Const.MOVIE_EXTENSION.indexOf(extension) == -1 && Const.SUBTITLE_EXTENTION.indexOf(extension) == -1)
            throw new FileException(Msg.FILEUTIL_ERROR_NOT_SUPPORT_EXTENSION);
    }
    
    
}
