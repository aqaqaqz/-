package util.utils;

import java.util.List;
import java.util.Map;

import util.utils.def.DefaultFileUtil;

public class PhotoUtil extends DefaultFileUtil{
	public void copyOriToTarget(String oriPath, String trgPath, List<String> oriExtensionList, List<String> trgExtensionList){
		Map<String, String> oriMap = getFileList(oriPath, oriExtensionList);
		Map<String, String> trgMap = getFileList(trgPath, trgExtensionList);
		
		
	}
}
