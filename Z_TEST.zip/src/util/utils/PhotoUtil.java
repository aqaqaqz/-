package util.utils;

import java.util.List;
import java.util.Map;

import exception.FileException;
import util.Util;
import util.utils.def.DefaultFileUtil;

public class PhotoUtil extends DefaultFileUtil{
	public String copyOriToTarget(String oriPath, String trgPath, String oriExtension, String trgExtension){
		String result = "작업이 완료되었습니다.";
		
		Map<String, String> oriMap = getFileList(oriPath, oriExtension);
		Map<String, String> trgMap = getFileList(trgPath, trgExtension);
		
		for(String oriName : oriMap.keySet()){
			String trgName = oriName.replace("."+oriExtension, "."+trgExtension);
			
			if(!trgMap.containsKey(trgName)) continue;
			
			String op = oriMap.get(oriName);
			String tp = trgMap.get(trgName).replace("."+trgExtension, "."+oriExtension);
			
			try{
				Util.file.copyDirectory(op, tp);
			}catch(FileException e){
				result = e.getMessage();
				break;
			}catch (Exception e){
				result = "알수없는 오류료 작업이 중단되었습니다.";
				break;
			}
		}
		
		return result;
	}
}
