package util.utils.def;


import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Msg;
import exception.FileException;


public class DefaultFileUtil {
	/**
     * 파일 정보
     */
    public File getFileInfo(String path) {
        File file = new File(path);
        if (!file.exists()) 
            throw new FileException(Msg.FILEUTIL_ERROR_NOT_EXIST_PATH);

        return file;
    }

    /**
     * 해당 경로가 존재하는지 확인
     */
    public boolean isExist(String path) {
        File file = new File(path);
        return file.exists();
    }

    /**
     * 파일 생성
     */
    public void makeDirectory(String target, String name) throws FileException {
        String path = target + "/" + name;
        if (isExist(path)) return;

        File f = new File(path);
        f.mkdir();
    }

    /**
     * 파일 삭제
     */
    public void removeDirectory(String path) throws FileException {
        File f = new File(path);
        if (!isExist(path)) 
            throw new FileException(Msg.FILEUTIL_ERROR_NOT_EXIST_PATH);

        f.delete();
    }

    /**
     * 파일 이동
     */
    public void moveDirectory(String target, String move) throws FileException {
        if (!isExist(target)) 
            throw new FileException(Msg.FILEUTIL_ERROR_NOT_EXIST_PATH);

        if (isExist(move)) 
            throw new FileException(Msg.FILEUTIL_ERROR_EXIST_PATH);

        File t = new File(target);
        File m = new File(move);
        t.renameTo(m);
    }


    /**
     * 확장자 구하기
     */
    public String getExtension(String name) {
    	String extension = "";
    	
    	try{
	        for (int i = name.length() - 1; i >= 0 && name.charAt(i) != '.'; i--)
	            extension = name.charAt(i) + extension;
    	}catch(Exception e){
    		System.out.println("확장자가 파일명에 존재하지 않습니다.");
    	}

        return extension;
    }
    
    /**
     * 확장자 구하기
     */
    public String removeExtension(String name) {
    	int i = name.length() - 1;
    	
    	try{
	        for (;i >= 0 && name.charAt(i) != '.'; i--);
	        return name.substring(0, i);
    	}catch(Exception e){
    		System.out.println("확장자가 파일명에 존재하지 않습니다.");
    	}

        return name;
    }
    
    /**
     * 파일 전체 리스트(폴더 제외)
     */
    public Map<String, String> getFileList(String path){
    	return getFileList(path, null);
    }
    public Map<String, String> getFileList(String path, List<String> extension){
    	Map<String, String> pathList = new HashMap();
    	
    	try {
	    	File f = new File(path);
	    	if(f.isDirectory()){
	    		for(File lower : f.listFiles()){
	    			if(extension == null)
	    				pathList.putAll(getFileList(lower.getPath()));
	    			else if(extension.indexOf(this.getExtension(f.getName())) > -1)
	    				pathList.putAll(getFileList(lower.getPath()));
	    		}
	    	}else pathList.put(f.getName(), f.getPath());
    	}catch(Exception e){
    		System.out.println("유효하지 않은 경로입니다.");
    	}
    	
    	return pathList;
    }
}
