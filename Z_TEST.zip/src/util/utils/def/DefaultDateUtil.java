package util.utils.def;


import java.util.Date;


public class DefaultDateUtil {
    public String getNowYearAndQuarter() {
        Date now = new Date();

        int year = now.getYear() + 1900;
        int month = now.getMonth();

        if (month == 12) return (year + 1) + "-1";
        if (month >= 1 && month <= 2) return year + "-1";
        if (month >= 3 && month <= 5) return year + "-2";
        if (month >= 6 && month <= 8) return year + "-3";
        return "" + year + "-4";
    }
}
