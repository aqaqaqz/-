package util.utils.def;


public class DefaultStringUtil {

    public boolean isEmpty(String s) {
        if (s == null || "".equals(s)) 
            return true;

        return false;
    }


    public String nvl(String ori, String replace) {
        if (isEmpty(ori)) 
            return replace;

        return ori;
    }
}
