package util.utils;


import util.utils.def.DefaultMouseUtil;


public class MouseUtil extends DefaultMouseUtil {

}
