package util.utils;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import model.Const;
import util.utils.def.DefaultStringUtil;


public class StringUtil extends DefaultStringUtil {

    public String getAnimationTitle(String name) {

        String title = name;

        for (String raw : Const.MOVIE_RAWS) {
            title = title.replace(raw, "");
        }

        Pattern pattern = Pattern.compile(Const.EPISODE_PATTERN);
        Matcher matcher = pattern.matcher(title);
        if (matcher.find()) {
            title = title.substring(0, matcher.start());
        }
        title = title.trim();

        return title;
    }
}
