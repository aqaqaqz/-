package util.utils;


import java.io.File;
import java.util.HashMap;
import java.util.Map;

import model.Const;
import model.Search;
import util.Util;


public class SearchUtil {

    protected static Search root = null;
    protected static Map<String, Search> cache = null;


    public Search getCache() {

        return getCache(Const.DEFAULT_PATH);
    }


    public Search getCache(String path) {

        if (cache == null) {
            syncData();
        }

        return cache.get(path);
    }


    /**
     * 케시 데이터를 동기화한다.
     */
    public void syncData() {

        cache = new HashMap<String, Search>();
        root = makeCache(Const.DEFAULT_PATH);
    }


    /**
     * 검색을 위한 케시를 생성한다.
     */
    private Search makeCache(String path) {

        File file = Util.file.getFileInfo(path);
        Search temp = new Search();

        temp.setPath(path);
        temp.setName(file.getName());
        temp.setDir(file.isDirectory());

        if (file.isDirectory()) {
            for (File f : file.listFiles()) {
                if (!isSearchTarget(f)) {
                    continue;
                }

                temp.getLower().add(makeCache(f.getPath()));
            }
        } else {

            String extension = Util.file.getExtension(temp.getName());

            for (String subtitleExtension : Const.SUBTITLE_EXTENTION) {
                String subtitlePath = file.getParent() + "\\" + file.getName().replaceAll("." + extension, "." + subtitleExtension);
                if (Util.file.isExist(subtitlePath)) {
                    temp.getSubtitleList().add(subtitleExtension);
                }
            }
        }

        cache.put(path, temp);

        return temp;
    }


    /**
     * 조회 대상인지 확인한다
     */
    private boolean isSearchTarget(File f) {

        if (f.isDirectory()) {
            return true;
        }

        if (Const.MOVIE_EXTENSION.indexOf(Util.file.getExtension(f.getName())) != -1) {
            return true;
        }

        return false;
    }


    /**
     * 제목이 속한 년도와 분기를 구한다(yyyy-q 의 구조). 없는 경우 "" 리턴
     */
    public String getQuarter(String name) {

        if (cache == null) {
            syncData();
        }

        for (Search quarter : root.getLower()) {
            for (Search title : quarter.getLower()) {
                if (name.equals(title.getName())) {
                    return quarter.getName();
                }
            }
        }

        return "";
    }

}
