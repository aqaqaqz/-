package util;


import model.PhotoPath;
import util.utils.DateUtil;
import util.utils.FileUtil;
import util.utils.MouseUtil;
import util.utils.PhotoUtil;
import util.utils.SearchUtil;
import util.utils.StringUtil;


public class Util {

    public static MouseUtil mouse = new MouseUtil();
    public static FileUtil file = new FileUtil();
    public static SearchUtil search = new SearchUtil();
    public static StringUtil string = new StringUtil();
    public static DateUtil date = new DateUtil();
    public static PhotoUtil photo = new PhotoUtil();

}
