package model;


import java.util.Arrays;
import java.util.List;


public class Const {

    public static List<String> SUBTITLE_EXTENTION = Arrays.asList("smi", "srt", "ass");
    public static List<String> MOVIE_EXTENSION = Arrays.asList("mp4", "mkv");
    public static List<String> MOVIE_RAWS = Arrays.asList("[Ohys-Raws]");
    public static String DEFAULT_PATH = "c:\\filetest\\";

    public static final String EPISODE_PATTERN = " - [0-9]{1,3}";
    public static final String ANIMATION_QUARTER_PATTERN = "[0-9]{4}-[0-9]{1}";
}
