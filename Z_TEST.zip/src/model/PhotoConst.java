package model;

import java.util.Arrays;
import java.util.List;

public class PhotoConst {
	public static final String TITLE = "Photo Util";
	public static final String FAVICON_PATH = "/src/img/favicon.ico";
    public static final int WINDOW_WIDTH = 800;
    public static final int WINDOW_HEIGHT = 250;
    
    public static final int TITLE_HEIGHT = 50;
    public static final int FILE_HEIGHT = 100;
    
    public static final List<String> ORI_EXTENSION = Arrays.asList("txt");
    public static final List<String> TRG_EXTENSION = Arrays.asList("jpg");
    
    public static final String ORI_TEXT = "원본";
    public static final String TRG_TEXT = "대상";
}
