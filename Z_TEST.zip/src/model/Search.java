package model;


import java.util.ArrayList;
import java.util.List;

public class Search {

    private String path;
    private String name;
    private boolean isDir;
    private List<String> subtitleList = new ArrayList<>();
    private List<Search> lower = new ArrayList();


    public String getPath() {

        return path;
    }


    public void setPath(String path) {

        this.path = path;
    }


    public String getName() {

        return name;
    }



    public void setName(String name) {

        this.name = name;
    }



    public boolean isDir() {

        return isDir;
    }



    public void setDir(boolean isDir) {

        this.isDir = isDir;
    }



    public List<String> getSubtitleList() {

        return subtitleList;
    }



    public void setSubtitleList(List<String> subtitleList) {

        this.subtitleList = subtitleList;
    }


    public List<Search> getLower() {

        return lower;
    }



    public void setLower(List<Search> lower) {

        this.lower = lower;
    }


}
