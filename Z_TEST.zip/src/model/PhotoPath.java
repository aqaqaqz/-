package model;

public class PhotoPath {
	private static String oriPath;
	private static String trgPath;
	
	public static void setOriPath(String oriPath){
		PhotoPath.oriPath = oriPath;
	}
	
	public static void setTrgPath(String trgPath){
		PhotoPath.trgPath = trgPath;
	}
	
	public static String getOriPath(){
		return PhotoPath.oriPath;
	}
	
	public static String getTrgPath(){
		return PhotoPath.trgPath;
	}
}
