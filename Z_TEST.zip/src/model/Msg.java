package model;


public class Msg {

    public static final String FILEUTIL_ERROR_EXIST_PATH = "이미 존재하는 경로입니다.";
    public static final String FILEUTIL_ERROR_NOT_EXIST_PATH = "존재하지 않는 경로입니다.";
    public static final String FILEUTIL_ERROR_DIRECOTRY_NOT_MOVE = "폴더는 이동이 불가능합니다.";
    public static final String FILEUTIL_ERROR_NOT_SUPPORT_EXTENSION = "지원하지 않는 확장자 입니다.";
    public static final String FILEUTIL_ERROR_FAIL_COPY_FILE = "파일 복사에 실패하였습니다.";
    public static final String FILEUTIL_ERROR_NOT_DIRECTORY = "폴더가 아닙니다.";
}
