import frame.DefaultFrame;
import util.Util;

public class Test {

    public static void main(String[] args) {
    	//new DefaultFrame();
        Util.mouse.preventScreenSaver();
    }
}
